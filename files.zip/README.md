# 🧾 レシート家計簿システム

iPhoneの「ショートカット」アプリと連携する、**完全自作のレシート家計簿**です。  
レシートを1枚撮影するだけで、Gemini APIがOCR解析し、自動的に家計簿に登録されます。

---

## ✨ 機能一覧

- 📸 **iPhoneから1タップ登録** — ショートカットアプリ連携
- 🤖 **Gemini API OCR** — レシート画像から日付・店名・金額・品目を自動抽出
- 💰 **月次合計表示** — 今月いくら使ったかが一目瞭然
- 📋 **品目詳細展開** — タップで購入品目を確認
- 🗑 **削除機能** — 誤登録をかんたん削除
- 📱 **iPhone最適化UI** — ダークテーマ・Safe Area対応

---

## 🏗 技術スタック

| 層 | 技術 |
|----|------|
| バックエンド | Node.js + Express |
| データベース | SQLite（better-sqlite3） |
| フロントエンド | Vanilla HTML/CSS/JS |
| 外部API | Google Gemini 1.5 Flash（OCR） |

---

## 🚀 セットアップ

### 1. リポジトリのクローン

```bash
git clone https://github.com/あなたのユーザー名/receipt-kakeibo.git
cd receipt-kakeibo
```

### 2. 依存パッケージのインストール

```bash
npm install
```

### 3. 環境変数の設定

```bash
cp .env.example .env
```

`.env` を編集：

```env
PORT=3000
DB_PATH=./data/kakeibo.db
NODE_ENV=development
```

### 4. サーバー起動

```bash
npm start
```

開発モード（自動再起動）：

```bash
npm run dev
```

### 5. ブラウザで開く

```
http://localhost:3000
```

---

## 📡 API リファレンス

### `POST /api/receipt` — レシート登録

```json
{
  "date": "2025-01-15",
  "store": "スーパーマーケット",
  "total_amount": 2480,
  "items": [
    {"name": "牛乳", "price": 198},
    {"name": "食パン", "price": 228}
  ]
}
```

**レスポンス (201)**:
```json
{
  "success": true,
  "message": "レシートを保存しました",
  "receipt_id": 1
}
```

---

### `GET /api/receipts` — 一覧取得

クエリパラメータ:
- `year`: 年（例: `2025`）
- `month`: 月（例: `1`）

---

### `DELETE /api/receipt/:id` — レシート削除

---

### `GET /api/summary` — 月次サマリー

---

## 📱 iPhoneショートカット設定

詳細な手順書は **[instructions.md](./instructions.md)** を参照してください。

### 必要なもの
- iPhone（iOS 16以上推奨）
- Google Gemini API キー（[無料取得](https://aistudio.google.com/app/apikey)）
- このサーバーへのアクセス（LAN or インターネット経由）

---

## 🌐 公開デプロイ（オプション）

### Railway（無料プラン対応）

```bash
# Railway CLIをインストール
npm install -g @railway/cli

# ログイン・デプロイ
railway login
railway init
railway up
```

### Render（無料プラン対応）

1. GitHubリポジトリをRenderに接続
2. Build Command: `npm install`
3. Start Command: `npm start`
4. 環境変数を設定

---

## 📁 ディレクトリ構造

```
receipt-kakeibo/
├── src/
│   ├── server.js          # Expressサーバー（エントリポイント）
│   ├── routes/
│   │   └── api.js         # APIルート
│   ├── db/
│   │   ├── database.js    # DB接続・テーブル作成
│   │   └── init.js        # DB初期化スクリプト
│   └── public/
│       ├── index.html     # フロントエンドHTML
│       ├── manifest.json  # PWAマニフェスト
│       ├── css/
│       │   └── style.css  # iPhone最適化スタイル
│       └── js/
│           └── app.js     # フロントエンドJS
├── data/                  # SQLiteファイル（自動作成・.gitignore対象）
├── instructions.md        # iPhoneショートカット設定マニュアル
├── .env.example           # 環境変数テンプレート
├── .gitignore
├── package.json
└── README.md
```

---

## 📝 データベース設計

```sql
-- レシート基本情報
CREATE TABLE receipts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  date         TEXT NOT NULL,        -- YYYY-MM-DD
  store        TEXT NOT NULL,        -- 店舗名
  total_amount INTEGER NOT NULL,     -- 合計金額（円）
  created_at   TEXT                  -- 登録日時
);

-- 購入品目（receiptsと1対多）
CREATE TABLE receipt_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_id INTEGER NOT NULL,       -- 外部キー
  name       TEXT NOT NULL,          -- 商品名
  price      INTEGER NOT NULL,       -- 金額（円）
  FOREIGN KEY (receipt_id) REFERENCES receipts(id) ON DELETE CASCADE
);
```

---

## 🔒 セキュリティ注意事項

- このシステムは**個人・家庭内利用**を想定しています
- インターネットに公開する場合は認証機能の追加を推奨します
- Gemini APIキーは絶対に `.env` 以外に記載しないでください

---

## 📄 ライセンス

MIT License

---

*Made with ❤️ — iPhoneで1タップ家計管理*
